/*
Affiche "bonjour le monde!"
*/
#include <stdio.h>

int main () {
    printf("\nbonjour le monde!\n\n");
    return 0;
}