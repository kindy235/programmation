
/**
 * C program to list contents of a directory recursively.
 */
 
 /***

Exercice 5.2 [*]


L'objectif de ce programme est de lister le contenu d'un repertoire de manière recursive.


***/



// Inclure les bibliothèques "sys/types", "dirent" pour utiliser la fonction 'opendir' et "unistd"
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>


// Inclure la bibliothèque "repertoire.h" qui contient les prototypes des fonctions, notamment 'lire_dossier_recursif'.
#include "repertoire.h"

// Inclure les bibliothèques "stdio" qui permet d'utiliser les fonctions 'printf', 'scanf'; "stdlib" et "string".
#include <stdlib.h>
#include <stdio.h>
#include <string.h>



// Implémentation de la fonction 'lire_dossier_recursif', avec une entrée pour prendre le nom du repertoire
void lire_dossier_recursif(char *chemin){

	
	// Déclaration du pointeur dirp, ce dernier est inialisé par le nom du répertoire à ouvrir avec la fonction 'opendir'
	DIR *dirp = opendir(chemin);
	
	
	// Si le pointeur dirp == NULL, le programme renvoie une erreur
  	if (dirp == NULL) {

		perror("opendir");
		exit(EXIT_FAILURE);

  	}


	// Déclaration du pointeur ent de type struct dirent (la structure de données nommée "direnté)
  	struct dirent *ent;
  	
  	// Déclaration d'une variable path de type char pouvant stockée 1000 caractères 
	char path[1000];
	

    	
	while ((ent = readdir(dirp)) != NULL) {
	
		if (strcmp(ent->d_name, ".") != 0 && strcmp(ent->d_name, "..") !=0) { 

			if (ent->d_type == DT_REG) {
				
				printf("%s/", chemin);

				printf("%s\n", ent->d_name);

			} 


			if (ent->d_type == DT_DIR) {
		   	
				printf("%s\n", ent->d_name);

				// Construct new path from our base path
				strcpy(path, chemin);
				strcat(path, "/");
				strcat(path, ent->d_name);

				lire_dossier_recursif(path);
			
			}
		
		}

	}

	
	// Fermer le nom du répertoire avec la fonction 'closedir'
	closedir(dirp);



}



// Fonction principale du programme
int main(int argc, char **argv) {

        
        // Si le nombre d'argument (nom du programme à exécuté, suivit du nom du repertoire) entrée en ligne de commande est inférieur à 2, le programme affiche une erreur
  	if (argc < 2) {
  		printf("Usage: readdir path\n");
  		return(EXIT_FAILURE);
  	}

	
	// On passe le paramètre argv[1] (qui est le nom du repertoire) en argument de la fonction 'lire_dossier'.
	lire_dossier_recursif(argv[1]);
  
  	
  	// Le programme retour '0' pour signaler sa fin (tout s'est bien exécuté)
	return(0);


}


