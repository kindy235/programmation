

void lire_dossier_iteratif(char *);
void lire_dossier_recursif(char *);
void lire_dossier(char *);
