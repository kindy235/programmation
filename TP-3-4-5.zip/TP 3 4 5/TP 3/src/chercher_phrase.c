


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(void) {
	

  	int i, j, k, test0=0, test1=0, test2=0, test3=0, test4=0, lenght;
	char recher[100]; // str1[50], str2[50];
	char* tablec[5] = {"MOELLE", "CHENGUITI ANSARI", "TEST1", "TEST2", "TEST3"};
    
	

	/* char* tablec[][17] = {
		"MOELLE",
		"CHENGUITI ANSARI",
		"TEST1",
		"TEST2",
		"TEST3"
		}; */
	
	


	printf("\n");

	/*	for(i = 0; i < 5; i++)
	{
	   for(j = 0; j < 17; j++)
           {
	   	printf("%s \t", tablec[i][j]);
           }
	  // printf("tablec[%d] \t", i, tablec[i]);
		
	}	*/

        printf("\n");

        printf("Recherche chaine de caractère, entrer la valeur \n");
        
        scanf("%s",recher);

		printf("%lu\n", strlen(recher));

		// lenght = strlen(recher) +1;
		lenght = strlen(recher);

		

       printf("\n");

       
	/* for(j = 0; recher[j]!='\0'; j++)	// recher[j]!='\0'
	{

	      //str1[j] = recher[j];

	      // printf("%c", str[j]);	// "%c", str[j]
	
	    

	      for (k = 0; tablec[j][k] != '\0'; k++)
	         {

		   // printf("%c ", tablec[j][k]);
			//str2[k] = tablec[j][k];

			
			/* if ( tablec[j][k] == str[k])
              		{
				test = 1;
                		// printf("Chaine de caractère trouvé \n"); 
              		} else {
				test = 0;
                  		// printf("Chaine de caractère non trouvé \n"); 
              		} 

                   
                 } 


	}  */


	for(i = 0; i<5; i++)	// recher[j]!='\0'
	{

		for (k = 0; tablec[i][k] != '\0' && recher[k]!='\0'; k++)
	    {

			//for(j = 0; recher[j]!='\0'; j++)	// recher[j]!='\0'
			//{

		   // printf("%c ", tablec[j][k]);
			//str2[k] = tablec[j][k];

				
				// Phrase 1 trouvée
				if (i == 0) {

					// printf("i = %d \n", i);
					
					if ( tablec[i][k] == recher[k])
              		{
						test0++;
                		// printf("Chaine de caractère trouvé %d \n", test0); 
						continue;
              		} else {
						test0 = 1;
                  		// printf("Chaine de caractère non trouvé %d \n", test0); 
						  break;
              		}

				}


				// Phrase 2 trouvée
				if (i == 1) {
					
					if ( tablec[i][k] == recher[k])
              		{
						test1++;
						continue;
                		// printf("Chaine de caractère trouvé %d \n", test1); 
              		} else {
						test1 = 2;
						break;
                  		// printf("Chaine de caractère non trouvé %d \n", test1); 
              		}

				}



				// Phrase 3 trouvée
				if (i == 2) {
					
					if ( tablec[i][k] == recher[k])
              		{
						test2++;
						continue;
                		// printf("Chaine de caractère trouvé %d \n", test2); 
              		} else {
						test2 = 3;
						break;
                  		// printf("Chaine de caractère non trouvé %d \n", test2); 
              		}

				}



				// Phrase 4 trouvée
				if (i == 3) {
					
					if ( tablec[i][k] == recher[k])
              		{
						test3++;
						continue;
                		// printf("Chaine de caractère trouvé %d \n", test3); 
              		} else {
						test3 = 4;
						break;
                  		// printf("Chaine de caractère non trouvé %d \n", test3); 
              		}

				}



				// Phrase 5 trouvée
				if (i == 4) {
					
					if ( tablec[i][k] == recher[k])
              		{
						test4++;
						continue;
                		// printf("Chaine de caractère trouvé %d \n", test4); 
              		} else {
						test4 = 5;
						break;
                  		// printf("Chaine de caractère non trouvé %d \n", test4); 
              		}

				}

                   
        } 

	}






		if ( test0 == lenght)
       {
            printf("Chaine de caractère trouvé %d \n", test0); 
       } else if (test0 == 1) {;
            printf("Chaine de caractère non trouvé %d \n", test0); 
       } 

	   if ( test1 == lenght)
       {
            printf("Chaine de caractère trouvé %d \n", test1); 
       } else if (test1 == 2) {;
            printf("Chaine de caractère non trouvé %d \n", test1); 
       } 

	   if ( test2 == lenght)
       {
            printf("Chaine de caractère trouvé %d \n", test2); 
       } else if (test0 == 3) {;
            printf("Chaine de caractère non trouvé %d \n", test2); 
       }

	   if ( test3 == lenght)
       {
            printf("Chaine de caractère trouvé %d \n", test3); 
       } else if (test3 == 4) {;
            printf("Chaine de caractère non trouvé %d \n", test3); 
       }

	   if ( test4 == lenght)
       {
            printf("Chaine de caractère trouvé %d \n", test4); 
       } else if (test4 == 5) {;
            printf("Chaine de caractère non trouvé %d \n", test4); 
       } 




  	printf("\n");

  
 


  return 0 ;

}
