

/***

Exercice 3.2 [*]

L'objectif de ce programme est de trouver la plus grande et la plus petite valeur dans un tableau de 100 entiers. 


***/



// Inclure la bibliothèque "stdio, qui permet d'utiliser les fonctions 'printf', 'scanf', etc.
#include <stdio.h>




// Fonction principale du programme
int main()
{
	
	// Déclaration des variables de type tableau et entier
	char tab[8] = {93, 22, 73, 92, 99, 15, 91, 73};
	int tab[100];
	int i, j, min, max, tmp, Pmin, Pmax;
	
	
	// Remplissage du tableau d'entier de manière aléatoire 
	
	
	for (int i = 0; i < 100; i++) {
	 *(tab + i) = rand() % 100;
	}
	
	// Deux saut de ligne
	printf("\n\n");
	

	// Affichage d'un message
	printf("Voici le tableau avec 100 entiers initialisés\n");
	
	
	// Affichage du tableau de 100 entiers
	for(j=0 ; j<8; j++)
	{
	   printf("%d \t", tab[j]);
	}
	
	// Un saut à la ligne
	printf("\n");
	
	
	// Recherche du maximum et minimum dans le tableau
	
	// Parcourir le tableau de 100 entiers
	for(i=0 ; i<8; i++)
	{
	    // A la première itération, on initialise les variables
	    // min et max à la valeur de tab d'indice 0 
	    // et Pmin, Pmax prenent la position 0
	    if (i == 0)
	    {
	      min = tab[i];
	      max = tab[i];
	      Pmin = i;
	      Pmax = i;
	    } 
	    // Sinon si la valeur de la tab d'indice i est < la valeur de min, on rendre dans la condition et min prend la valeur de la tab d'indice i, Pmin la valeur de l'indice i.
	    else if (tab[i] < min) {
	      min = tab[i];
	      Pmin = i;
	    } 
	    
	    // Sinon si la valeur de la tab d'indice i est > la valeur de max, on rendre dans la condition et max prend la valeur de la tab d'indice i, Pmax la valeur de l'indice i.
	    else if (tab[i] > max) {
	      max = tab[i];
	      Pmax = i;
	    }
	    
	    
	}
	
	
	// Un saut à la ligne
	printf("\n");
	
	
	// Affichages du plus grand et petit nombre trouver dans le tableau de 100 entiers.
	
	printf("Le numéro plus grand est : %d \n Position %d \n", max, Pmax);
	
	printf("\n\n");
	
	printf("Le numéro plus petit est : %d \n Position %d \n", min, Pmin);
	
	
	// Deux sauts à la ligne
	printf("\n\n");
	
	
	// Le programme retour '0' pour signaler sa fin (tout s'est bien exécuté)
	return 0;

}
