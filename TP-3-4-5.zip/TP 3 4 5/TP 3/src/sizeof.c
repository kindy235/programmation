
/***

Exercice 3.1 [*]

L'objectif de ce programme est d'afficher la taille des différentes
types de variables ci-dessous via la fonction "sizeofe", tout en sachant que la machine est à 64 bits, ainsi que le SE Linux. 


***/


// Inclure la bibliothèque "stdio, qui permet d'utiliser les fonctions 'printf', 'scanf', etc.
#include <stdio.h>


// Fonction principale du programme
int main(void) {

  
  // Affichage de la taille du type de variable 'int', résultat = 4 octets
  printf("sizeof(int): %lu", sizeof (int));
  printf("\n") ;


 // Affichage de la taille des type de variable pointeurs,    résultats = 8 octets
  printf("sizeof(int *): %lu", sizeof (int *));
  printf("\n") ;

  printf("sizeof(int **): %lu", sizeof (int **));
  printf("\n") ;

  printf("sizeof(char *): %lu", sizeof (char *));
  printf("\n") ;

  printf("sizeof(char **): %lu", sizeof (char **));
  printf("\n") ;

  printf("sizeof(char ***): %lu", sizeof (char ***));
  printf("\n") ;

  printf("sizeof(float *): %lu", sizeof (float *));
  printf("\n") ;

  printf("sizeof(float **): %lu", sizeof (float **));
  printf("\n") ;

  printf("sizeof(float ***): %lu", sizeof (float ***));
  printf("\n") ;
 

  // Le programme retour '0' pour signaler sa fin (tout s'est bien exécuté)
  return 0 ;

}
