
/***

Exercice 3.3 [**]

Ce programme a pour objectif de créer un tableau de 100 entiers rempli aléatoirement, puis de trier ce dernier par ordre croissant.


***/



// Inclure la bibliothèque "stdio, qui permet d'utiliser les fonctions 'printf', 'scanf', etc.
#include <stdio.h>



// Fonction principale du programme
int main()
{
	
	// Déclaration des variables de type tableau et entier
	int tab[8] = {93, 22, 73, 92, 99, 15, 91, 12};
	int i, j, tmp;

	
	
	
	// Remplissage du tableau d'entier de manière aléatoire 
	
	
	
	
	// Deux saut de ligne
	printf("\n\n");
	
	
	// Affichage d'un message
	printf("Voici le tableau avec 100 entiers initialisés\n");
	
	
	// Affichage du tableau de 100 entiers
	for(j = 0 ; j < 8 /*sizeof(tab)*/; j++)
	{
	   printf("%d \t", tab[j]);
	}
	
	
	// Deux saut de ligne
	printf("\n\n");
	
	
	// Affichage d'un message
	printf("Voici le tableau trié par ordre croissant \n");
	
	
	
	// Trié par ordre croissant
	
	// Parcourir le tableau de 100 entiers 
	for(i = 0 ; i < 8 /*sizeof(tab)*/; i++)
	{
	   // Parcourir à partir de l'indice suivant l'indice 'i' jusqu'à la fin d'indice du tableau de 100 entiers
	   for(j = i+1 ; j < 8 /*sizeof(tab)*/; j++)
	   {
	   
	       // Si la valeur de la tab d'indice 'i' est > a la valeur de la tab d'indice 'j', on rentre dans la condition et tmp (variable temporaire) prend la valeur de la tab d'indice 'i', la tab d'indice 'i' prend la valeur de la tab d'indice 'j' et la tab d'indice 'j' prend la valeur de tmp.
	       if (tab[i] > tab[j])
	       {
		      tmp = tab[i];
		      tab[i] = tab[j];
		      tab[j] = tmp;   
	        }
	        
	    }
	    
	    
	    // Affichage du tableau trié par ordre croissant 
	    printf("%d \t", tab[i]);
	}
	
	
	// Deux sauts à la ligne
	printf("\n\n");
	
	
	
	// Le programme retour '0' pour signaler sa fin (tout s'est bien exécuté)
	return 0;
	
	

}
