

/***

Exercice 3.6 [**]

Ce programme a pour objectif de voir les valeurs de chaque octet des différents type de varaible ci-dessous, en fonction de la valeur attribuée aux variables de ces types.


***/




// Inclure la bibliothèque "stdio, qui permet d'utiliser les fonctions 'printf', 'scanf', etc.
#include <stdio.h>



// Fonction principale du programme
int main(void) {
	

  
  // Déclaration et initialisation des variables des types différents
  
  short v1 = 254;
  
  int v2 = 2676;

  long int v3 = 6738902;

  float v4 = 35.34;

  double v5 = 2356.35678;

  long double v6 = 2367899.3677288;
  
  

  // Déclaration d'un pointeur de type vide (c'est-à-dire ce pointeur peu prendre l'adresse de n'importe quel type de variable)
  void *p;
  // Déclaration d'un pointeur de type char
  char *c;





  // Initialisation du pointeur 'p' avec l'adresse de la variable  'v1'
  p = &v1;
  // Initialisation du pointeur 'c' avec le pointeur 'p'
  c = p;
  
  // Un saut de ligne
  printf("\n");
  // Incrémentation de la taille des octets du type short
  for (unsigned short i = 0; i < sizeof(short); i++)
      {
      	 // Affichage de l'indice, ainsi que de la valeur de chaque octet de la variable de type short
         printf(" O[%hu] = %d \n", i, *(c+i));
      }




   // Initialisation du pointeur 'p' avec l'adresse de la variable  'v2'
  p = &v2;
  // Initialisation du pointeur 'c' avec le pointeur 'p'
  c = p;
  
  printf("\n");
   // Incrémentation de la taille des octets du type int
  for (unsigned int i = 0; i < sizeof(int); i++)
      {
         // Affichage de l'indice, ainsi que de la valeur de chaque octet de la variable de type int
         printf(" O[%u] = %d \n", i, *(c+i));
      }
      
      
      

   // Initialisation du pointeur 'p' avec l'adresse de la variable  'v3'
  p = &v3;
  // Initialisation du pointeur 'c' avec le pointeur 'p'
  c = p;
  
  printf("\n");
   // Incrémentation de la taille des octets du type long int
  for (unsigned long i = 0; i < sizeof(long int); i++)
      {
         // Affichage de l'indice, ainsi que de la valeur de chaque octet de la variable de type long int
         printf(" O[%lu] = %d \n", i, *(c+i));
      }

 
 
 
   // Initialisation du pointeur 'p' avec l'adresse de la variable  'v4'
  p = &v4;
  // Initialisation du pointeur 'c' avec le pointeur 'p'
  c = p;
  
  printf("\n");
   // Incrémentation de la taille des octets du type float
  for (unsigned long i = 0; i < sizeof(float); i++)
      {
         // Affichage de l'indice, ainsi que de la valeur de chaque octet de la variable de type float
         printf(" O[%lu] = %d \n", i, *(c+i));
      }



 
   // Initialisation du pointeur 'p' avec l'adresse de la variable  'v5'
  p = &v5;
  // Initialisation du pointeur 'c' avec le pointeur 'p'
  c = p;
  
  printf("\n");
   // Incrémentation de la taille des octets du type double
  for (unsigned long i = 0; i < sizeof(double); i++)
      {
         // Affichage de l'indice, ainsi que de la valeur de chaque octet de la variable de type double
         printf(" O[%lu] = %d \n", i, *(c+i));
      }




   // Initialisation du pointeur 'p' avec l'adresse de la variable  'v6'
  p = &v6;
  // Initialisation du pointeur 'c' avec le pointeur 'p'
  c = p;
  
  printf("\n");
   // Incrémentation de la taille des octets du type long double
  for (unsigned long i = 0; i < sizeof(long double); i++)
      {
         // Affichage de l'indice, ainsi que de la valeur de chaque octet de la variable de type long double
         printf(" O[%lu] = %d \n", i, *(c+i));
      }

  

  // Un saut de ligne
  printf("\n");

  
 

  // Le programme retour '0' pour signaler sa fin (tout s'est bien exécuté)
  return 0 ;

}
